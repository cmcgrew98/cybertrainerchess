"""Unit tests for Cyber Trainer server core helpers.

Run from the Trainer folder with:
    py -m unittest discover -s tests
or:
    python -m unittest discover -s tests

The scoring and rating-floor tests do not require python-chess. PGN parsing
coverage is skipped automatically if python-chess is unavailable.
"""

import importlib.util
import sys
import types
import unittest

_REAL_CHESS_AVAILABLE = importlib.util.find_spec("chess") is not None

if not _REAL_CHESS_AVAILABLE:
    chess_stub = types.ModuleType("chess")
    pgn_stub = types.ModuleType("chess.pgn")
    chess_stub.pgn = pgn_stub
    sys.modules.setdefault("chess", chess_stub)
    sys.modules.setdefault("chess.pgn", pgn_stub)

import trainer_server as srv


def session_state(*, rating=2400, total=10, credits=0, bonus=0, guesses=0, moves_guessed=0, hard_fail_count=0):
    return {
        "master_rating": rating,
        "total_moves": total,
        "credits": credits,
        "bonus_credits": bonus,
        "guesses": guesses,
        "moves_guessed": moves_guessed,
        "hard_fail_count": hard_fail_count,
    }


class ScoreBarTests(unittest.TestCase):
    def test_initial_ceiling_is_master_rating(self):
        sc = srv._score(session_state())
        self.assertEqual(sc["score"], 0)
        self.assertEqual(sc["bar_floor"], 200)
        self.assertEqual(sc["bar_ceiling"], 2400)

    def test_exact_match_preserves_full_ceiling(self):
        sc = srv._score(session_state(credits=1, guesses=1, moves_guessed=1))
        self.assertEqual(sc["score"], 2400)
        self.assertEqual(sc["bar_ceiling"], 2400)
        self.assertGreater(sc["bar_floor"], 200)

    def test_first_hard_fail_lowers_ceiling_immediately(self):
        initial = srv._score(session_state())
        after_hard_fail = srv._score(session_state(guesses=1, moves_guessed=0, hard_fail_count=1))
        self.assertLess(after_hard_fail["bar_ceiling"], initial["bar_ceiling"])
        # The current position has already been spent by the hard fail; the
        # retry is for learning/advancement only, not another scoring chance.
        self.assertEqual(after_hard_fail["bar_ceiling"], round(2400 * 9 / 10))

    def test_second_hard_fail_does_not_lower_ceiling_again(self):
        after_first = srv._score(session_state(guesses=1, moves_guessed=0, hard_fail_count=1))
        after_second = srv._score(session_state(guesses=1, moves_guessed=1, hard_fail_count=0))
        self.assertEqual(after_second["moves_left"], 9)
        self.assertEqual(after_second["bar_ceiling"], after_first["bar_ceiling"])

    def test_match_after_hard_fail_has_same_ceiling_as_reveal(self):
        # Finding the master move after one hard fail resolves the position,
        # but does not restore match credit or add a second denominator penalty.
        resolved_after_retry = srv._score(session_state(guesses=1, moves_guessed=1, hard_fail_count=0))
        revealed_after_two_hard_fails = srv._score(session_state(guesses=1, moves_guessed=1, hard_fail_count=0))
        self.assertEqual(resolved_after_retry["bar_ceiling"], revealed_after_two_hard_fails["bar_ceiling"])

    def test_bonus_credit_can_raise_ceiling(self):
        exact = srv._score(session_state(credits=1, guesses=1, moves_guessed=1))
        bonus = srv._score(session_state(credits=1, bonus=1, guesses=1, moves_guessed=1))
        self.assertGreater(bonus["bar_ceiling"], exact["bar_ceiling"])
        self.assertEqual(bonus["bar_ceiling"], round(2400 * 10.25 / 10))

    def test_zero_total_moves_is_safe(self):
        sc = srv._score(session_state(total=0))
        self.assertEqual(sc["bar_floor"], 200)
        self.assertEqual(sc["bar_ceiling"], 200)


class RatingFloorTests(unittest.TestCase):
    def test_world_champion_floor_applies(self):
        self.assertEqual(srv._world_class_floor("Jose Raul Capablanca"), 2725)
        self.assertEqual(srv._world_class_floor("Bobby Fischer"), 2780)

    def test_edward_lasker_is_excluded(self):
        self.assertEqual(srv._world_class_floor("Edward Lasker"), 0)
        self.assertEqual(srv._world_class_floor("Ed. Lasker"), 0)

    def test_short_tokens_do_not_false_match_inside_names(self):
        self.assertEqual(srv._world_class_floor("Derrikson"), 0)  # must not match "so"
        self.assertEqual(srv._world_class_floor("Vitaly Smith"), 0)  # must not match "tal"


@unittest.skipUnless(_REAL_CHESS_AVAILABLE, "python-chess not installed")
class PgnParsingTests(unittest.TestCase):
    def test_parse_single_white_win(self):
        pgn = '''[Event "Smoke"]\n[White "Capablanca"]\n[Black "NN"]\n[Result "1-0"]\n\n1. e4 e5 2. Nf3 Nc6 1-0\n'''
        parsed = srv.parse_pgn_file(pgn)
        self.assertTrue(parsed.get("ok"), parsed)
        self.assertEqual(parsed["count"], 1)
        fid = parsed["file_id"]
        game = srv._pgn_cache[fid][0]
        self.assertEqual(game["prepared_side"], "white")
        self.assertEqual(game["total_moves"], 2)
        self.assertGreaterEqual(game["master_rating"], 2725)

    def test_parse_single_black_win(self):
        pgn = '''[Event "Smoke"]\n[White "NN"]\n[Black "Alekhine"]\n[Result "0-1"]\n\n1. e4 Nf6 2. e5 Nd5 0-1\n'''
        parsed = srv.parse_pgn_file(pgn)
        self.assertTrue(parsed.get("ok"), parsed)
        game = srv._pgn_cache[parsed["file_id"]][0]
        self.assertEqual(game["prepared_side"], "black")
        self.assertGreaterEqual(game["master_rating"], 2690)

    def test_draw_defaults_to_white(self):
        pgn = '''[Event "Smoke"]\n[White "WhitePlayer"]\n[Black "BlackPlayer"]\n[Result "1/2-1/2"]\n\n1. e4 e5 1/2-1/2\n'''
        parsed = srv.parse_pgn_file(pgn)
        self.assertTrue(parsed.get("ok"), parsed)
        game = srv._pgn_cache[parsed["file_id"]][0]
        self.assertEqual(game["prepared_side"], "white")

    def test_study_mainline_returns_all_plies_with_fen_after(self):
        pgn = '''[Event "Study"]\n[White "Capablanca"]\n[Black "NN"]\n[Result "1-0"]\n\n1. e4 {[%csl Ge4] Claim center.} e5 {Black replies.} 2. Nf3 Nc6 1-0\n'''
        parsed = srv.parse_pgn_file(pgn)
        self.assertTrue(parsed.get("ok"), parsed)
        game = srv._pgn_cache[parsed["file_id"]][0]
        mainline = srv._study_mainline(game)
        self.assertEqual(len(mainline), 4)
        self.assertEqual(mainline[0]["ply"], 1)
        self.assertEqual(mainline[0]["uci"], "e2e4")
        self.assertEqual(mainline[0]["annotation"], "Claim center.")
        self.assertIn({"type":"circle","square":"e4","color":"green"}, mainline[0]["overlays"])
        board = chess.Board(mainline[0]["fen_before"])
        board.push(chess.Move.from_uci(mainline[0]["uci"]))
        self.assertEqual(mainline[0]["fen_after"], board.fen())

    def test_study_response_is_read_only_and_starts_at_initial_position(self):
        pgn = '''[Event "Study"]\n[White "Capablanca"]\n[Black "NN"]\n[Result "1-0"]\n\n1. e4 e5 1-0\n'''
        parsed = srv.parse_pgn_file(pgn)
        self.assertTrue(parsed.get("ok"), parsed)
        game = srv._pgn_cache[parsed["file_id"]][0]
        response = srv._study_response(game)
        self.assertEqual(response["mode"], "study")
        self.assertEqual(response["current_fen"], game["starting_fen"])
        self.assertEqual(response["auto_played"], [])
        self.assertEqual(len(response["study_mainline"]), game["total_plies"])
        session = srv.get_session(response["session_id"])
        self.assertEqual(session["move_index"], 0)

        pgn = '''[Event "Bad"]\n[White "A"]\n[Black "B"]\n[Result "?"]\n\n1. e4 e5 *\n'''
        parsed = srv.parse_pgn_file(pgn)
        self.assertIn("error", parsed)
        self.assertIn("No valid games", parsed["error"])




@unittest.skipUnless(_REAL_CHESS_AVAILABLE, "python-chess not installed")
class MateScoreNormalisationTests(unittest.TestCase):
    def test_white_checkmate_of_black_is_positive_even_when_engine_reports_mate_zero(self):
        board = srv.chess.Board()
        for uci in ["e2e4", "e7e5", "f1c4", "b8c6", "d1h5", "g8f6", "h5f7"]:
            board.push(srv.chess.Move.from_uci(uci))
        self.assertTrue(board.is_checkmate())
        self.assertEqual(board.turn, srv.chess.BLACK)
        self.assertEqual(srv._engine_mate_to_white_pov(board, 0), 1)
        self.assertEqual(srv._normalise_white_pov_mate(board, 0), 1)

    def test_black_checkmate_of_white_is_negative_even_when_engine_reports_mate_zero(self):
        board = srv.chess.Board()
        for uci in ["f2f3", "e7e5", "g2g4", "d8h4"]:
            board.push(srv.chess.Move.from_uci(uci))
        self.assertTrue(board.is_checkmate())
        self.assertEqual(board.turn, srv.chess.WHITE)
        self.assertEqual(srv._engine_mate_to_white_pov(board, 0), -1)
        self.assertEqual(srv._normalise_white_pov_mate(board, 0), -1)


class PgnOverlayTagTests(unittest.TestCase):
    def test_extracts_lichess_style_circle_and_arrow_tags(self):
        overlays = srv._extract_pgn_overlays("[%csl Ge4,Rd5][%cal Gd2d4,Bg1f3] Plan")
        self.assertIn({"type":"circle","square":"e4","color":"green"}, overlays)
        self.assertIn({"type":"circle","square":"d5","color":"red"}, overlays)
        self.assertIn({"type":"arrow","from":"d2","to":"d4","color":"green"}, overlays)
        self.assertIn({"type":"arrow","from":"g1","to":"f3","color":"blue"}, overlays)

    def test_strips_graphics_tags_from_visible_annotation_text(self):
        self.assertEqual(srv._strip_pgn_overlays("[%csl Ge4] [%cal Rd8d4] This is prose."), "This is prose.")

    def test_serializes_overlays_back_to_pgn_tags(self):
        tags = srv._pgn_overlay_tags([
            {"type":"circle","square":"e4","color":"green"},
            {"type":"arrow","from":"d2","to":"d4","color":"red"},
            {"type":"arrow","from":"g1","to":"f3","color":"gold"},
        ])
        self.assertIn("[%csl Ge4]", tags)
        self.assertIn("[%cal Rd2d4,Yg1f3]", tags)




class AnalysisSummaryTests(unittest.TestCase):
    def test_cp_to_win_percent_center_and_extremes(self):
        self.assertAlmostEqual(srv._eval_to_win_percent({"cp": 0, "mate": None}), 50.0, places=3)
        self.assertGreater(srv._eval_to_win_percent({"cp": 1000, "mate": None}), 95.0)
        self.assertLess(srv._eval_to_win_percent({"cp": -1000, "mate": None}), 5.0)

    def test_mate_to_win_percent_extremes(self):
        self.assertEqual(srv._eval_to_win_percent({"cp": None, "mate": 1}), 100.0)
        self.assertEqual(srv._eval_to_win_percent({"cp": None, "mate": -1}), 0.0)

    def test_accuracy_and_loss_classification_thresholds(self):
        self.assertEqual(srv._classify_win_loss(9.99), None)
        self.assertEqual(srv._classify_win_loss(10.0), "inaccuracy")
        self.assertEqual(srv._classify_win_loss(20.0), "mistake")
        self.assertEqual(srv._classify_win_loss(30.0), "blunder")
        self.assertEqual(srv._move_accuracy_from_win_loss(0), 100.0)
        self.assertLess(srv._move_accuracy_from_win_loss(30), srv._move_accuracy_from_win_loss(10))

    def test_build_analysis_summary_uses_side_to_move_pov(self):
        moves = [
            {"color": "white", "san": "e4", "uci": "e2e4", "move_number": 1},
            {"color": "black", "san": "e5", "uci": "e7e5", "move_number": 1},
        ]
        # White drops from near winning to equal: a blunder.  Black then also
        # drops from equal for Black to losing for Black: a blunder for Black.
        evals = [
            {"ply": 0, "cp": 1000, "mate": None},
            {"ply": 1, "cp": 0, "mate": None},
            {"ply": 2, "cp": 1000, "mate": None},
        ]
        summary = srv._build_analysis_summary(moves, evals)
        self.assertTrue(summary["ok"])
        self.assertEqual(summary["white"]["blunder"], 1)
        self.assertEqual(summary["black"]["blunder"], 1)
        self.assertEqual(len(summary["markers"]), 2)

    @unittest.skipUnless(_REAL_CHESS_AVAILABLE, "python-chess not installed")
    def test_standard_start_gets_synthetic_root_eval_when_missing(self):
        evs = srv._evals_with_synthetic_root([{"ply": 1, "cp": 30, "mate": None}], srv.chess.STARTING_FEN)
        self.assertEqual(evs[0]["ply"], 0)
        self.assertEqual(evs[0]["cp"], 20)
        self.assertTrue(evs[0].get("synthetic"))

    @unittest.skipUnless(_REAL_CHESS_AVAILABLE, "python-chess not installed")
    def test_nonstandard_start_does_not_get_synthetic_root_eval(self):
        fen = "8/8/8/8/8/8/8/K6k w - - 0 1"
        evs = srv._evals_with_synthetic_root([{"ply": 1, "cp": 30, "mate": None}], fen)
        self.assertFalse(any(int(e.get("ply", -1)) == 0 for e in evs))

    @unittest.skipUnless(_REAL_CHESS_AVAILABLE, "python-chess not installed")
    def test_synthetic_root_allows_first_move_analysis_for_standard_start(self):
        moves = [{"color": "white", "san": "e4", "uci": "e2e4", "move_number": 1}]
        evals = [{"ply": 1, "cp": -1000, "mate": None}]
        summary = srv._build_analysis_summary(moves, evals, srv.chess.STARTING_FEN)
        self.assertTrue(summary["ok"])
        self.assertEqual(summary["evaluated_moves"], 1)
        self.assertGreaterEqual(summary["white"]["blunder"], 1)

class SubmitMoveMetadataStaticTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        from pathlib import Path
        cls.server = Path(__file__).resolve().parents[1].joinpath("trainer_server.py").read_text(encoding="utf-8")

    def test_server_tag_updated_to_57(self):
        self.assertIn('BUILD_TAG   = "CT-SRV-57"', self.server)
        self.assertIn('{"build":BUILD_TAG', self.server)

    def test_submit_move_computes_user_san_for_tried_moves(self):
        self.assertIn("user_san=board.san(um)", self.server)
        self.assertGreaterEqual(self.server.count('"user_uci":user_uci'), 5)
        self.assertGreaterEqual(self.server.count('"user_san":user_san'), 5)

    def test_hard_fail_response_includes_failed_position_fen(self):
        self.assertIn("user_move_fen=_apply_move(fb,user_uci)", self.server)
        self.assertIn('"user_move_fen":user_move_fen', self.server)


class FrontendStaticTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        from pathlib import Path
        root = Path(__file__).resolve().parents[1]
        cls.html = root.joinpath("trainer.html").read_text(encoding="utf-8")
        cls.server = root.joinpath("trainer_server.py").read_text(encoding="utf-8")

    def _between(self, start, end):
        i = self.html.index(start)
        j = self.html.index(end, i)
        return self.html[i:j]

    def test_ct_build_tag_updated_to_58_server_tag_updated_to_57(self):
        self.assertIn("CT-BUILD-58", self.html)
        self.assertNotIn("CT-BUILD-55c", self.html)
        self.assertNotIn("CT-BUILD-54b", self.html)
        self.assertNotIn("CT-BUILD-53a", self.html)
        self.assertEqual(getattr(srv, "BUILD_TAG", ""), "CT-SRV-57")

    def test_game_library_instruction_is_present(self):
        self.assertIn("Select a game from the list below, then choose a mode.", self.html)
        self.assertIn("browser-instruction", self.html)

    def test_game_library_mode_choice_is_prominent_not_row_cramped(self):
        self.assertIn('id="browser-mode-chooser"', self.html)
        self.assertIn('id="btn-browser-train"', self.html)
        self.assertIn('id="btn-browser-study"', self.html)
        self.assertIn('Start Training Mode', self.html)
        self.assertIn('Start Study Mode', self.html)
        self.assertIn('function selectBrowserGame(gameIndex, rowEl)', self.html)
        self.assertIn('function startSelectedBrowserGame(mode)', self.html)
        self.assertNotIn('mini-mode-btn', self.html)
        browser_css = self._between('/* ── Multi-game browser ── */', '.browser-meta')
        self.assertIn('grid-template-columns: 24px 1fr 42px 28px;', browser_css)
        self.assertIn('.mode-chooser', browser_css)

    def test_study_mode_parallel_paste_button_and_under_board_nav_exist(self):
        self.assertIn('id="btn-study-load"', self.html)
        self.assertIn('onclick="loadStudyGame()"', self.html)
        board_col = self._between('<!-- ── Left: Board ── -->', '<!-- ── Right: Info ── -->')
        self.assertIn('id="study-nav"', board_col)
        self.assertIn('id="btn-study-back"', board_col)
        self.assertIn('id="btn-study-forward"', board_col)
        self.assertIn('studyStep(-1)', board_col)
        self.assertIn('studyStep(1)', board_col)

    def test_study_mode_uses_separate_endpoints_and_not_submit_move(self):
        self.assertIn('/load_study_game', self.html)
        self.assertIn('/start_study_game', self.html)
        study_load = self._between('async function loadStudyGame()', 'async function handleLoadResponse')
        self.assertIn('/load_study_game', study_load)
        self.assertNotIn('/submit_move', study_load)
        study_browser = self._between('async function startStudyFromBrowser', 'async function submitMove')
        self.assertIn('/start_study_game', study_browser)
        self.assertNotIn('/submit_move', study_browser)


    def test_study_mode_enables_engine_annotation_controls(self):
        self.assertIn('ANNOTATION DEPTH (PLY)', self.html)
        self.assertIn('function getAnnotationDepth(confirmSlow = true)', self.html)
        study_load = self._between('async function handleStudyLoadResponse', 'function studyMoveLabel')
        self.assertIn("annotBtn.disabled = false;", study_load)
        self.assertIn("Run engine annotation for this study game", study_load)
        self.assertIn("Annotate Game", study_load)
        annotate = self._between('async function annotateGame()', 'async function saveAnnotatedPgn()')
        self.assertIn('const depth = getAnnotationDepth(true);', annotate)
        self.assertIn('JSON.stringify({session_id: state.sessionId, depth})', annotate)
        self.assertIn("annotationCompleted ? 'Re-annotate' : 'Annotate Game'", annotate)

    def test_annotated_pgn_saves_to_outputs_folder(self):
        self.assertIn('OUTPUT_DIR     = "Outputs"', self.server)
        self.assertIn('os.makedirs(output_dir,exist_ok=True)', self.server)
        self.assertIn('relpath=os.path.join(OUTPUT_DIR,filename)', self.server)
        self.assertIn('"path":relpath', self.server)
        save_fn = self._between('async function saveAnnotatedPgn()', 'async function pollEngineStatus()')
        self.assertIn('d.path || d.filename', save_fn)

    def test_server_accepts_annotation_depth_from_request(self):
        annotate_server = self.server.split('elif path=="/annotate_game":', 1)[1].split('elif path=="/submit_move":', 1)[0]
        self.assertIn('requested_depth=int(body.get("depth"', annotate_server)
        self.assertIn('depth=max(1,min(99,requested_depth))', annotate_server)

    def test_study_mode_hides_training_controls_and_uses_right_annotation_panel(self):
        collapse_study = self._between('function collapseForStudy()', 'function expandForLoad()')
        self.assertIn("state.mode = 'study';", collapse_study)
        self.assertIn("document.getElementById('feedback-section').style.display = '';", collapse_study)
        self.assertIn("document.getElementById('play-options-section').style.display = 'none';", collapse_study)
        self.assertIn("document.getElementById('continue-section').style.display = 'none';", collapse_study)
        self.assertIn("document.getElementById('perf-bar-wrap').style.display = 'none';", collapse_study)
        self.assertIn("scoreSection.style.display = 'none';", collapse_study)

    def test_study_navigation_updates_current_ply_annotation_and_overlays(self):
        self.assertIn('studyMainline:', self.html)
        self.assertIn('function showStudyPly(ply, opts = {})', self.html)
        study_ply = self._between('function showStudyPly(ply, opts = {})', 'function studyStep(delta)')
        self.assertIn("switchContentTab('annotation');", study_ply)
        self.assertIn('state.moveIndex = nextPly;', study_ply)
        self.assertIn('renderBoard(move.fen_after);', study_ply)
        self.assertIn('showPositionOverlaysForCurrentPly();', study_ply)
        self.assertIn('setFeedback', study_ply)
        self.assertNotIn('showContinue', study_ply)

    def test_study_mode_keeps_piece_input_disabled(self):
        can_interact = self._between('function canInteract()', '// ── Drag state')
        self.assertIn("state.mode === 'training'", can_interact)

    def test_revert_button_is_not_present(self):
        self.assertNotIn('Revert', self.html)
        self.assertNotIn('revert', self.html)

    def test_play_options_panel_is_not_inside_engine_panel(self):
        self.assertIn('id="play-options-section"', self.html)
        play_options = self._between('id="play-options-section"', '<!-- Feedback')
        self.assertIn("PAUSE AFTER EVERY MATCH", play_options)
        self.assertIn("SHOW REFUTATION", play_options)
        engine_panel = self._between('id="section-engine"', '<!-- Server status -->')
        self.assertNotIn("PAUSE AFTER EVERY MATCH", engine_panel)
        self.assertNotIn("SHOW REFUTATION", engine_panel)

    def test_pause_checkbox_default_uses_v2_unchecked_key(self):
        self.assertIn("ct_pause_after_every_match_v2", self.html)
        self.assertIn("state.pauseAfterMatch = saved === null ? false : saved === 'true';", self.html)

    def test_play_options_shows_during_game_and_hides_on_load_screen(self):
        self.assertIn("document.getElementById('play-options-section').style.display = '';", self.html)
        self.assertIn("document.getElementById('play-options-section').style.display = 'none';", self.html)

    def test_tried_moves_ui_is_present(self):
        self.assertIn('id="tried-moves"', self.html)
        self.assertIn("function addTriedMove(category, d)", self.html)
        self.assertIn("function resetTriedMoves()", self.html)
        self.assertIn("Tried this position:", self.html)

    def test_tried_moves_records_bonus_excellent_soft_and_hard_attempts(self):
        move_result = self._between("function handleMoveResult", "function animatePiece")
        self.assertIn("addTriedMove('bonus', d);", move_result)
        self.assertIn("addTriedMove('excellent', d);", move_result)
        self.assertIn("addTriedMove('soft_fail', d);", move_result)
        self.assertIn("addTriedMove('hard_fail', d);", move_result)

    def test_tried_moves_reserves_bonus_label_for_awarded_bonus(self):
        meta = self._between("function triedMoveMeta(category)", "function addTriedMove")
        self.assertIn("bonus:     { icon: '★', label: 'bonus' }", meta)
        self.assertIn("excellent: { icon: '↑', label: 'excellent' }", meta)
        non_awarded = self._between("} else {\n      state.pendingRefutationReturn = null;", "// Note: d.annotation intentionally withheld")
        self.assertIn("\\u2191 Excellent!", non_awarded)
        self.assertNotIn("+0.25", non_awarded)

    def test_tried_moves_suppresses_duplicate_attempts(self):
        add_fn = self._between("function addTriedMove(category, d)", "function renderTriedMoves")
        self.assertIn("Suppress duplicate attempts", add_fn)
        self.assertIn("alreadyTried", add_fn)
        self.assertIn("state.triedMoves.some", add_fn)
        self.assertIn("return;", add_fn)

    def test_tried_moves_reset_on_new_game_and_resolution(self):
        load_response = self._between("async function handleLoadResponse", "function clearActiveGameState")
        self.assertIn("state.triedMoves       = [];", load_response)
        self.assertIn("renderTriedMoves();", load_response)
        exact_section = self._between("if (result === 'exact')", "// ── BONUS")
        self.assertIn("resetTriedMoves();", exact_section)
        master_show = self._between("function _fireMasterShow()", "function _fireBonusRetract")
        self.assertIn("resetTriedMoves();", master_show)
        bonus_retract = self._between("function _fireBonusRetract()", "// ═══════════════════════════════════════════════════════════════════\n//  Square interaction")
        self.assertIn("resetTriedMoves();", bonus_retract)

    def test_two_hard_fail_message_includes_second_move_cp_deficit(self):
        two_hard_section = self._between("result === 'two_hard_fails'", "showContinue('master_show');")
        self.assertIn("const cp = d.delta_cp ? Math.round(d.delta_cp) : 0;", two_hard_section)
        self.assertIn("cp below the master", two_hard_section)
        self.assertIn("Click Continue to see the master move", two_hard_section)

    def test_game_over_returns_to_selection_instead_of_restart_only(self):
        panel = self._between('id="game-over-panel"', '<!-- Game info -->')
        self.assertIn("Choose Another Game", panel)
        self.assertIn("returnToSelection()", panel)
        self.assertNotIn("Play Again", panel)

    def test_quit_current_game_button_is_visible_during_play_options(self):
        play_options = self._between('id="play-options-section"', '<!-- Feedback')
        self.assertIn("Quit Current Game", play_options)
        self.assertIn("quitCurrentGame()", play_options)

    def test_return_to_selection_exposes_browser_and_load_panel(self):
        ret = self._between("function returnToSelection()", "function quitCurrentGame()")
        self.assertIn("browser.classList.remove('collapsed');", ret)
        self.assertIn("loadSection.classList.remove('collapsed');", ret)
        self.assertIn("section-load", ret)
        self.assertIn("section-browser", ret)

    def test_return_to_selection_clears_pending_play_state(self):
        clear_state = self._between("function clearActiveGameState()", "function returnToSelection()")
        self.assertIn("state.pendingAutoMoves = null;", clear_state)
        self.assertIn("state.pendingOppMove = null;", clear_state)
        self.assertIn("state.pendingBonusRetract = null;", clear_state)
        self.assertIn("state.pendingMasterShow = null;", clear_state)
        self.assertIn("hideContinue();", clear_state)

    def test_annotated_match_continue_autoplays_opponent_reply(self):
        self.assertIn("showContinue('advance_auto');", self.html)
        self.assertIn("_fireAdvance({autoOpponent: true});", self.html)
        self.assertIn("Annotated matches always pause", self.html)


    def test_bonus_awarded_path_autoplays_opponent_reply_after_master_continuation(self):
        bonus_retract = self._between("function _fireBonusRetract()", "// ═══════════════════════════════════════════════════════════════════\n//  Square interaction")
        self.assertIn("Bonus-awarded positions", bonus_retract)
        self.assertIn("{autoOpponent: true}", bonus_retract)
        self.assertIn("playAutoMoves(state.pendingAutoMoves || [], state.pendingFinalFen, state.pendingCallback, {autoOpponent: true});", bonus_retract)

    def test_black_opening_uses_explicit_opening_sequence_flag(self):
        self.assertIn("{openingSequence: true}", self.html)
        self.assertIn("!!opts.openingSequence", self.html)
        self.assertIn("showContinue('opp_open');", self.html)

    def test_two_hard_fail_does_not_leak_annotation_before_master_move(self):
        two_hard_section = self._between("result === 'two_hard_fails'", "showContinue('master_show');")
        self.assertIn("Click Continue to see the master move", two_hard_section)
        self.assertIn("d.annotation || ''", two_hard_section)  # stored for later
        feedback_prefix = two_hard_section.split("state.pendingMasterShow", 1)[0]
        self.assertNotIn("d.annotation", feedback_prefix)

    def test_master_reveal_shows_annotation_only_after_animation(self):
        master_show = self._between("function _fireMasterShow()", "function _fireBonusRetract")
        self.assertIn("animatePiece(masterFrom, masterTo", master_show)
        self.assertIn("const note = ms.masterAnn || ''", master_show)
        self.assertIn("renderBoard(ms.masterFen);", master_show)
        render_idx = master_show.index("renderBoard(ms.masterFen);")
        note_idx = master_show.index("const note = ms.masterAnn || ''")
        self.assertLess(render_idx, note_idx)
        self.assertIn("showContinue('advance_auto');", master_show)

    def test_pause_checkbox_label_is_every_match_not_annotation_only(self):
        self.assertIn("PAUSE AFTER EVERY MATCH", self.html)
        self.assertNotIn("PAUSE AFTER MATCH ANNOTATIONS", self.html)


    def test_ct54_overlay_layer_exists_and_is_non_interactive(self):
        self.assertIn('id="board-overlay-svg"', self.html)
        self.assertIn('class="board-overlay-svg"', self.html)
        self.assertIn('.board-overlay-svg', self.html)
        self.assertIn('pointer-events: none;', self.html)
        self.assertIn('z-index: 5;', self.html)

    def test_ct54_overlay_state_api_and_required_colors_exist(self):
        self.assertIn('boardOverlays:', self.html)
        self.assertIn('const BOARD_OVERLAY_COLORS', self.html)
        for color in ['red', 'blue', 'green', 'gold']:
            self.assertIn(f'{color}:', self.html)
        self.assertIn('function setBoardOverlays(overlays, opts = {})', self.html)
        self.assertIn('function clearBoardOverlays(opts = {})', self.html)
        self.assertIn('window.setBoardOverlays = setBoardOverlays;', self.html)
        self.assertIn('window.clearBoardOverlays = clearBoardOverlays;', self.html)

    def test_ct54b_overlay_palette_uses_richer_lichess_like_hues(self):
        colors = self._between('const BOARD_OVERLAY_COLORS', 'const overlayGesture')
        self.assertIn("red:   '#882020'", colors)
        self.assertIn("blue:  '#003088'", colors)
        self.assertIn("green: '#15781B'", colors)
        self.assertIn("gold:  '#e68f00'", colors)
        self.assertNotIn('#e74c3c', colors)
        self.assertNotIn('#3498db', colors)
        self.assertNotIn('#2ecc71', colors)

    def test_ct54_overlay_supports_circle_and_arrow_rendering(self):
        self.assertIn("type: 'circle'", self.html)
        self.assertIn("type: 'arrow'", self.html)
        self.assertIn('function drawBoardOverlay(svg, overlay)', self.html)
        self.assertIn("document.createElementNS(ns, 'circle')", self.html)
        self.assertIn("document.createElementNS(ns, 'path')", self.html)
        self.assertIn('One filled polygon avoids marker/shaft overlap', self.html)
        self.assertNotIn('marker-end', self.html)
        self.assertNotIn('board-overlay-arrowhead-', self.html)
        self.assertIn('stroke-opacity', self.html)
        self.assertIn('fill-opacity', self.html)

    def test_ct54b_overlay_opacity_circle_and_arrow_geometry(self):
        draw_fn = self._between('function drawBoardOverlay(svg, overlay)', 'function activeBoardOverlayPreview()')
        self.assertIn("const opacity = '0.42';", draw_fn)
        self.assertIn('const strokeWidth = Math.max(6, c.size * 0.12) * 0.75;', draw_fn)
        self.assertIn('(c.size / 2) - (strokeWidth / 2)', draw_fn)
        self.assertIn('const shaftHalf = Math.max(2.5, a.size * 0.050);', draw_fn)
        self.assertIn('const headLength = Math.min(a.size * 0.48', draw_fn)
        self.assertIn('const headHalf = Math.max(shaftHalf * 2.60', draw_fn)
        self.assertIn("path.setAttribute('stroke', 'none');", draw_fn)

    def test_ct54_overlay_square_centers_use_rendered_dom_positions(self):
        center_fn = self._between('function boardOverlaySquareCenter(square)', 'function boardOverlayKey(overlay)')
        self.assertIn('getBoundingClientRect()', center_fn)
        self.assertIn('document.querySelector(`[data-sq=', center_fn)
        self.assertIn('sr.left - wr.left + sr.width / 2', center_fn)
        self.assertIn('sr.top  - wr.top  + sr.height / 2', center_fn)

    def test_ct54_overlay_redraws_after_board_render_and_resize(self):
        render_fn = self._between('function renderBoard(fen)', 'function buildLabels()')
        self.assertIn('redrawBoardOverlays();', render_fn)
        self.assertIn("window.addEventListener('resize', redrawBoardOverlays);", self.html)

    def test_ct54b_overlay_color_protocol_matches_lichess(self):
        color_fn = self._between('function overlayColorForEvent(e)', 'function isBoardOverlayGestureEvent(e)')
        self.assertIn("if (e.altKey && e.ctrlKey) return 'gold';", color_fn)
        self.assertIn("if (e.altKey) return 'blue';", color_fn)
        self.assertIn("if (e.ctrlKey) return 'red';", color_fn)
        self.assertIn("return 'green';", color_fn)
        normalise_fn = self._between('function normaliseOverlayColor(color)', 'function overlayColorForEvent(e)')
        self.assertIn("return BOARD_OVERLAY_COLORS[color] ? color : 'green';", normalise_fn)

    def test_ct54_overlay_gesture_wiring_uses_right_mouse_and_ctrl_left(self):
        gesture_fn = self._between('function isBoardOverlayGestureEvent(e)', 'function boardOverlaySquareCenter(square)')
        self.assertIn('e.button === 2', gesture_fn)
        self.assertIn('e.button === 0 && e.ctrlKey', gesture_fn)
        self.assertIn("boardWrapEl.addEventListener('mousedown', beginBoardOverlayGesture);", self.html)
        self.assertIn("boardWrapEl.addEventListener('contextmenu'", self.html)
        square_mouse = self._between("el.addEventListener('mousedown', e =>", "// Touch drag start")
        self.assertIn('if (isBoardOverlayGestureEvent(e)) return;', square_mouse)
        click_fn = self._between('async function onSquareClick(sq)', '// ═══════════════════════════════════════════════════════════════════\n//  Multi-game browser')
        self.assertIn('overlayGesture.suppressClick', click_fn)

    def test_ct54_overlay_gesture_toggles_circles_and_arrows(self):
        toggle_fn = self._between('function toggleBoardOverlay(overlay)', 'function beginBoardOverlayGesture(e)')
        self.assertIn('const next = cloneBoardOverlays(state.boardOverlays || []);', toggle_fn)
        self.assertIn('next.splice(existing, 1);', toggle_fn)
        self.assertIn('next.push(safe);', toggle_fn)
        self.assertIn('persistCurrentPositionOverlays();', toggle_fn)
        end_fn = self._between('function endBoardOverlayGesture(e)', '// Expose the generic API')
        self.assertIn("toggleBoardOverlay({ type: 'circle'", end_fn)
        self.assertIn("toggleBoardOverlay({ type: 'arrow'", end_fn)

    def test_ct55_overlay_state_clears_on_major_game_transitions(self):
        load_response = self._between('async function handleLoadResponse', 'function clearActiveGameState')
        self.assertIn('showPositionOverlaysForCurrentPly();', load_response)
        clear_state = self._between('function clearActiveGameState()', 'function returnToSelection()')
        self.assertIn('clearBoardOverlayState();', clear_state)
        load_game = self._between('async function loadGame()', 'async function handleLoadResponse')
        self.assertIn('clearBoardOverlayState();', load_game)
        file_selected = self._between('async function onFileSelected(event)', '// ═══════════════════════════════════════════════════════════════════\n//  UI updates')
        self.assertIn('clearBoardOverlayState();', file_selected)
        game_over = self._between('function showGameOver(sc, norm)', 'function normLabel(score)')
        self.assertIn('clearBoardOverlayState();', game_over)

    def test_ct55_overlays_are_position_scoped_and_persisted(self):
        self.assertIn('positionOverlays:', self.html)
        self.assertIn('function currentOverlayPly()', self.html)
        self.assertIn('function showPositionOverlaysForCurrentPly()', self.html)
        self.assertIn('function persistCurrentPositionOverlays()', self.html)
        self.assertIn('/update_position_overlays', self.html)
        submit = self._between('async function submitMove(fromSq, toSq)', 'function handleMoveResult')
        self.assertIn('show_refutation: state.showRefutation', submit)
        auto = self._between('function _animatePendingOppMove()', '// ═══════════════════════════════════════════════════════════════════\n//  Game loading')
        self.assertIn('showPositionOverlaysForCurrentPly();', auto)

    def test_ct55b_show_refutation_pauses_on_failed_move_board(self):
        self.assertIn('id="show-refutation"', self.html)
        self.assertIn('ct_show_refutation_v1', self.html)
        self.assertIn('refutationOverlay:', self.html)
        self.assertIn('pendingRefutationReturn:', self.html)
        self.assertIn("'return_refutation': 'Return to the game position", self.html)
        self.assertIn('function _fireReturnFromRefutation()', self.html)
        hard = self._between("result === 'hard_fail'", "// ── TWO HARD FAILS")
        self.assertIn('const refOverlay = refutationOverlayForHardFail(d);', hard)
        self.assertIn('if (refOverlay && d.user_move_fen)', hard)
        self.assertIn('renderBoard(d.user_move_fen);', hard)
        self.assertIn("showContinue('return_refutation');", hard)
        self.assertIn('Try again from the game position', hard)
        self.assertNotIn('This shows the failed move on the board', hard)

    def test_ct55c_exact_match_after_hard_fail_omits_scoring_parenthetical(self):
        exact_section = self._between("if (result === 'exact')", "// ── BONUS")
        self.assertNotIn('Position resolved after earlier hard fail', exact_section)
        self.assertIn('\\u2713 Match', exact_section)

    def test_ct55b_refutation_can_use_saved_red_arrow(self):
        self.assertIn('function firstRedArrowOverlay(overlays)', self.html)
        self.assertIn('function refutationOverlayForHardFail(d)', self.html)
        ref_fn = self._between('function refutationOverlayForHardFail(d)', 'function redrawBoardOverlays()')
        self.assertIn('d.refutation && d.refutation.overlay', ref_fn)
        self.assertIn('firstRedArrowOverlay(state.boardOverlays || [])', ref_fn)

    def test_ct56c_eval_graph_does_not_treat_mate_zero_as_black_advantage(self):
        self.assertIn('function evalCpForGraphPoint(e)', self.html)
        helper = self._between('function evalCpForGraphPoint(e)', 'function drawEvalGraph')
        self.assertIn('if (m > 0) return 9999;', helper)
        self.assertIn('if (m < 0) return -9999;', helper)
        self.assertIn('return 0;', helper)
        graph = self._between('function drawEvalGraph', 'function switchContentTab')
        self.assertIn('const cp = evalCpForGraphPoint(e);', graph)
        self.assertNotIn('e.mate > 0 ? 9999 : -9999', graph)

    def test_ct57_analysis_summary_ui_and_filtering_exist(self):
        self.assertIn('id="analysis-summary"', self.html)
        self.assertIn('id="analysis-filter-inaccuracy"', self.html)
        self.assertIn('id="analysis-filter-mistake"', self.html)
        self.assertIn('id="analysis-filter-blunder"', self.html)
        self.assertIn('function renderAnalysisSummary(summary)', self.html)
        self.assertIn('function setAnalysisFilter(filter)', self.html)

    def test_ct57_graph_markers_click_to_study_ply_without_submit_move(self):
        graph = self._between('function drawEvalGraph', 'function switchContentTab')
        self.assertIn('markerSummary.markers', graph)
        self.assertIn('onEvalGraphMarkerClick', graph)
        click = self._between('function onEvalGraphMarkerClick', 'function analysisMarkerTitle')
        self.assertIn("state.mode === 'study'", click)
        self.assertIn('showStudyPly(target, {preserveTab: true});', click)
        self.assertNotIn('/submit_move', click)

    def test_ct57_annotation_done_updates_analysis_summary(self):
        annotate = self._between('async function annotateGame()', 'async function saveAnnotatedPgn()')
        self.assertIn('root_eval', annotate)
        self.assertIn('msg.analysis_summary', annotate)
        self.assertIn('renderAnalysisSummary(state.analysisSummary);', annotate)

    def test_ct58_study_eval_bar_exists_and_is_study_only(self):
        self.assertIn('id="study-eval-bar"', self.html)
        self.assertIn('function updateStudyEvalBar()', self.html)
        bar_fn = self._between('function updateStudyEvalBar()', 'function graphPlyFromMouseEvent')
        self.assertIn("state.mode !== 'study'", bar_fn)
        self.assertIn("bar.classList.add('visible')", bar_fn)
        self.assertIn('formatEvalText(ev)', bar_fn)
        self.assertIn('Math.tanh(Number(cp || 0) / 500)', bar_fn)

    def test_ct58_graph_uses_root_ply_and_full_width_mapping(self):
        graph = self._between('function drawEvalGraph', 'function switchContentTab')
        self.assertIn('Number(e.ply || 0) >= 0', graph)
        self.assertIn('return PAD_L + (Number(ply || 0) / n) * GW;', graph)
        self.assertNotIn('(ply - 0.5) / n', graph)
        self.assertIn('eval-graph-hit-area', graph)

    def test_ct58_graph_click_and_drag_jump_study_without_submit_move(self):
        self.assertIn('function graphPlyFromMouseEvent(event)', self.html)
        self.assertIn('function jumpStudyGraphEvent(event', self.html)
        self.assertIn('function beginEvalGraphDrag(event)', self.html)
        jump = self._between('function jumpStudyGraphEvent(event', 'function beginEvalGraphDrag')
        self.assertIn("state.mode !== 'study'", jump)
        self.assertIn('showStudyPly(ply, {preserveTab: true});', jump)
        self.assertNotIn('/submit_move', jump)
        self.assertIn('state.evalGraphDragging', self.html)



if __name__ == "__main__":
    unittest.main()
